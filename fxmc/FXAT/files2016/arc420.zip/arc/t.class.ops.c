.// $RCSfile: t.class.ops.c,v $

/*----------------------------------------------------------------------------
 * Operation action methods implementation for the following class:
 *
 * Class:      ${te_class.Name}  ($r{te_class.Key_Lett})
 * Component:  ${te_c.Name}
 *--------------------------------------------------------------------------*/
.//
