.if ( "SystemC" != te_thread.flavor )
${ws}ARCH_shutdown();
.end if
