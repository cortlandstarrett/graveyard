${te_blk.indentation}if ( ${condition_te_val.buffer} ) {
