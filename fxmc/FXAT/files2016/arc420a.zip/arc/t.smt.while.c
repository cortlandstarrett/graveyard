${te_blk.indentation}while ( ${condition_te_val.buffer} ) {
